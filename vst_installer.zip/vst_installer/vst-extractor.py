import os
import zipfile
import py7zr
from pathlib import Path
import tempfile
import logging

class VSTExtractor:
    def __init__(self, temp_dir: str = None):
        """
        Initialize VST Extractor with optional custom temporary directory.
        
        Args:
            temp_dir (str, optional): Custom temporary directory for extractions
        """
        self.logger = logging.getLogger(self.__class__.__name__)
        self.temp_dir = Path(temp_dir or tempfile.gettempdir()) / 'vst_extractions'
        self.temp_dir.mkdir(parents=True, exist_ok=True)
    
    def extract(self, archive_path: Path) -> Path:
        """
        Extract compressed archives with support for zip and 7z formats.
        
        Args:
            archive_path (Path): Path to the compressed archive
        
        Returns:
            Path: Directory containing extracted contents
        """
        extraction_dir = self.temp_dir / archive_path.stem
        extraction_dir.mkdir(parents=True, exist_ok=True)
        
        try:
            if archive_path.suffix.lower() == '.zip':
                with zipfile.ZipFile(archive_path, 'r') as zip_ref:
                    zip_ref.extractall(extraction_dir)
            
            elif archive_path.suffix.lower() == '.7z':
                with py7zr.SevenZipFile(archive_path, 'r') as seven_zip:
                    seven_zip.extractall(extraction_dir)
            
            self.logger.info(f"Successfully extracted {archive_path}")
            return extraction_dir
        
        except Exception as e:
            self.logger.error(f"Extraction error for {archive_path}: {e}")
            raise
