import os
import sys
import subprocess
import shutil
import winreg
import logging
from typing import List, Dict, Optional
from pathlib import Path

# Import custom modules
from vst_extractor import VSTExtractor
from vst_installer import VSTInstaller
from vst_gui import VSTInstallerGUI

class VSTAutoInstaller:
    def __init__(self, 
                 input_directory: str, 
                 output_directory: Optional[str] = None,
                 log_level: int = logging.INFO):
        """
        Initialize the VST Auto Installer with comprehensive configuration.
        
        Args:
            input_directory (str): Source directory containing VST installers
            output_directory (str, optional): Destination for installed VSTs
            log_level (int): Logging verbosity level
        """
        # Configure logging
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('vst_installer.log'),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Validate and normalize paths
        self.input_directory = Path(input_directory).resolve()
        self.output_directory = Path(output_directory or self._get_default_vst_directory()).resolve()
        
        # Create instances of helper classes
        self.extractor = VSTExtractor()
        self.installer = VSTInstaller()
        
        # Validate directories
        self._validate_directories()
        
    def _get_default_vst_directory(self) -> Path:
        """
        Determine the default VST installation directory.
        Prefers 64-bit VST directory if available.
        
        Returns:
            Path: Recommended VST installation path
        """
        program_files = Path(os.environ.get('ProgramFiles', 'C:\\Program Files'))
        vst_paths = [
            program_files / 'VST',
            program_files / 'VST3',
            program_files / 'Steinberg' / 'VSTPlugins'
        ]
        
        # Check for 64-bit and 32-bit paths
        for path in vst_paths:
            if path.exists():
                return path
        
        # Fallback and create directory if none exist
        default_path = program_files / 'VST'
        default_path.mkdir(parents=True, exist_ok=True)
        return default_path
    
    def _validate_directories(self):
        """
        Validate input and output directories, creating output if needed.
        Raises exceptions for invalid configurations.
        """
        if not self.input_directory.is_dir():
            raise ValueError(f"Input directory does not exist: {self.input_directory}")
        
        self.output_directory.mkdir(parents=True, exist_ok=True)
        
        self.logger.info(f"Input Directory: {self.input_directory}")
        self.logger.info(f"Output Directory: {self.output_directory}")
    
    def run_installation(self, 
                         extensions: List[str] = ['.exe', '.msi', '.zip', '.7z'],
                         dry_run: bool = False) -> Dict[str, bool]:
        """
        Recursively scan and install VST plugins.
        
        Args:
            extensions (List[str]): File extensions to process
            dry_run (bool): If True, simulate installation without actual installation
        
        Returns:
            Dict[str, bool]: Installation results for each plugin
        """
        installation_results = {}
        
        for root, _, files in os.walk(self.input_directory):
            for file in files:
                if any(file.lower().endswith(ext) for ext in extensions):
                    full_path = Path(root) / file
                    
                    try:
                        # Extract if compressed
                        if full_path.suffix in ['.zip', '.7z']:
                            extracted_path = self.extractor.extract(full_path)
                            root = extracted_path
                        
                        # Attempt installation
                        if not dry_run:
                            result = self.installer.install_vst(
                                full_path, 
                                self.output_directory
                            )
                            installation_results[str(full_path)] = result
                        else:
                            self.logger.info(f"Dry run: Would install {full_path}")
                    
                    except Exception as e:
                        self.logger.error(f"Error processing {full_path}: {e}")
                        installation_results[str(full_path)] = False
        
        return installation_results

def main():
    """
    Main entry point for VST Auto Installer.
    Allows CLI or GUI-based installation.
    """
    if len(sys.argv) > 1:
        # CLI Mode
        installer = VSTAutoInstaller(sys.argv[1])
        installer.run_installation()
    else:
        # GUI Mode
        VSTInstallerGUI().run()

if __name__ == "__main__":
    main()
