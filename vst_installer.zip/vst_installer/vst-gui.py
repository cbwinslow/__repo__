import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import os
from pathlib import Path

class VSTInstallerGUI:
    def __init__(self):
        """
        Initialize the VST Installer GUI with clean, modern design.
        """
        self.root = tk.Tk()
        self.root.title("VST Plugin Batch Installer")
        self.root.geometry("600x500")
        
        # Set up style for modern look
        self.style = ttk.Style()
        self.style.configure('TLabel', font=('Arial', 10))
        self.style.configure('TButton', font=('Arial', 10))
        
        self._create_widgets()
    
    def _create_widgets(self):
        """
        Create and layout GUI widgets with thoughtful design.
        """
        # Input Directory Selection
        ttk.Label(self.root, text="Input Directory (VST Installers):").pack(pady=(10, 5))
        self.input_dir_entry = ttk.Entry(self.root, width=70)
        self.input_dir_entry.pack(pady=5, padx=20)
        
        input_dir_button = ttk.Button(
            self.root, 
            text="Browse", 
            command=self._select_input_directory
        )
        input_dir_button.pack(pady=5)
        
        # Output Directory Selection
        ttk.Label(self.root, text="Output Directory (VST Plugins):").pack(pady=(10, 5))
        self.output_dir_entry = ttk.Entry(self.root, width=70)
        self.output_dir_entry.pack(pady=5, padx=20)
        
        output_dir_button = ttk.Button(
            self.root, 
            text="Browse", 
            command=self._select_output_directory
        )
        output_dir_button.pack(pady=5)
        
        # Options Frame
        options_frame = ttk.LabelFrame(self.root, text="Installation Options")
        options_frame.pack(pady=10, padx=20, fill='x')
        
        # Checkboxes for additional options
        self.dry_run_var = tk.BooleanVar(value=False)
        dry_run_check = ttk.Checkbutton(
            options_frame, 
            text="Dry Run (Simulate Installation)", 
            variable=self.dry_run_var
        )
        dry_run_check.pack(pady=5, padx=10)
        
        # Installation Button
        install_button = ttk.Button(
            self.root, 
            text="Start Installation", 
            command=self._start_installation
        )
        install_button.pack(pady=20)
        
        # Log Display
        self.log_text = tk.Text(
            self.root, 
            wrap=tk.WORD, 
            height=10, 
            width=70
        )
        self.log_text.pack(pady=10, padx=20)
    
    def _select_input_directory(self):
        """Select input directory for VST installers."""
        directory = filedialog.askdirectory()
        self.input_dir_entry.delete(0, tk.END)
        self.input_dir_entry.insert(0, directory)
    
    def _select_output_directory(self):
        """Select output directory for VST plugins."""
        directory = filedialog.askdirectory()
        self.output_dir_entry.delete(0, tk.END)
        self.output_dir_entry.insert(0, directory)
    
    def _start_installation(self):
        """
        Initiate VST plugin installation process.
        """
        input_dir = self.input_dir_entry.get()
        output_dir = self.output_dir_entry.get()
        dry_run = self.dry_run_var.get()
        
        if not input_dir or not output_dir:
            messagebox.showerror("Error", "Please select both input and output directories.")
            return
        
        try:
            from vst_installer_main import VSTAutoInstaller
            
            installer = VSTAutoInstaller(
                input_directory=input_dir, 
                output_directory=output_dir
            )
            
            results = installer.run_installation(dry_run=dry_run)
            
            # Update log display
            self.log_text.delete('1.0', tk.END)
            for path, status in results.items():
                status_text = "✓ Successful" if status else "✗ Failed"
                self.log_text.insert(tk.END, f"{path}: {status_text}\n")
            
            messagebox.showinfo("Installation Complete", "VST Plugin Installation Finished!")
        
        except Exception as e:
            messagebox.showerror("Installation Error", str(e))
    
    def run(self):
        """Run the GUI application."""
        self.root.mainloop()

if __name__ == "__main__":
    VSTInstallerGUI().run()
