import os
import subprocess
import shutil
import winreg
import logging
from pathlib import Path

class VSTInstaller:
    def __init__(self):
        """
        Initialize VST Installer with logging and error handling.
        """
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def install_vst(self, installer_path: Path, output_directory: Path) -> bool:
        """
        Intelligently install VST plugins based on file type.
        
        Args:
            installer_path (Path): Path to installer
            output_directory (Path): Destination VST directory
        
        Returns:
            bool: Installation success status
        """
        try:
            # Executable installers
            if installer_path.suffix.lower() in ['.exe', '.msi']:
                return self._run_installer(installer_path)
            
            # Direct file copy for DLLs
            elif installer_path.suffix.lower() == '.dll':
                return self._copy_dll(installer_path, output_directory)
            
            # Unsupported file type
            else:
                self.logger.warning(f"Unsupported file type: {installer_path}")
                return False
        
        except Exception as e:
            self.logger.error(f"Installation error for {installer_path}: {e}")
            return False
    
    def _run_installer(self, installer_path: Path) -> bool:
        """
        Execute Windows installers with appropriate flags for silent/minimal installation.
        
        Args:
            installer_path (Path): Path to executable installer
        
        Returns:
            bool: Installation success status
        """
        silent_flags = {
            '.exe': ['/S', '/SILENT', '/VERYSILENT'],
            '.msi': ['/passive', '/qn']
        }
        
        for flag_set in silent_flags.get(installer_path.suffix.lower(), []):
            try:
                result = subprocess.run(
                    [str(installer_path), flag_set], 
                    capture_output=True, 
                    text=True, 
                    timeout=300  # 5-minute timeout
                )
                
                if result.returncode == 0:
                    self.logger.info(f"Successfully installed {installer_path}")
                    return True
            except subprocess.TimeoutExpired:
                self.logger.warning(f"Installation timed out: {installer_path}")
            except Exception as e:
                self.logger.error(f"Installer execution failed: {e}")
        
        return False
    
    def _copy_dll(self, dll_path: Path, output_directory: Path) -> bool:
        """
        Copy VST DLL to appropriate installation directory.
        
        Args:
            dll_path (Path): Source DLL path
            output_directory (Path): Destination VST directory
        
        Returns:
            bool: Copy success status
        """
        try:
            destination = output_directory / dll_path.name
            shutil.copy2(dll_path, destination)
            self.logger.info(f"Copied {dll_path} to {destination}")
            return True
        except Exception as e:
            self.logger.error(f"DLL copy failed: {e}")
            return False
